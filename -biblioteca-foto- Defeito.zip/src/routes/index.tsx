import { ClientOnly, createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

import App from "../App";
import { ThemeProvider } from "../context/ThemeContext";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Biblioteca Maria Quitéria" },
      {
        name: "description",
        content:
          "Sistema de gerenciamento e portal da Biblioteca Maria Quitéria com catálogo de livros, controle de empréstimos, relatórios e painel administrativo.",
      },
      { property: "og:title", content: "Biblioteca Maria Quitéria" },
      {
        property: "og:description",
        content:
          "Sistema de gerenciamento e portal da Biblioteca Maria Quitéria com catálogo de livros, controle de empréstimos, relatórios e painel administrativo.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function VLibrasWidget() {
  useEffect(() => {
    const init = () => {
      try {
        const VLibrasCtor = (
          window as unknown as { VLibras?: { Widget: new (url: string) => void } }
        ).VLibras;
        if (VLibrasCtor) {
          new VLibrasCtor.Widget("https://vlibras.gov.br/app");
        }
      } catch (e) {
        console.warn("VLibras widget failed to initialize:", e);
      }
    };

    if ((window as unknown as { VLibras?: unknown }).VLibras) {
      init();
      return;
    }
    const script = document.createElement("script");
    script.src = "https://vlibras.gov.br/app/vlibras-plugin.js";
    script.onload = init;
    document.body.appendChild(script);
  }, []);

  return (
    <div {...{ vw: "" }} className="enabled">
      <div {...{ "vw-access-button": "" }} className="active" />
      <div {...{ "vw-plugin-wrapper": "" }}>
        <div className="vw-plugin-top-wrapper" />
      </div>
    </div>
  );
}

function Index() {
  return (
    <ClientOnly
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-[#13072b]">
          <p className="text-purple-200">Carregando a Biblioteca Maria Quitéria…</p>
        </div>
      }
    >
      <ThemeProvider>
        <App />
        <VLibrasWidget />
      </ThemeProvider>
    </ClientOnly>
  );
}
