import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Setter<T> = T | ((prev: T) => T);

/**
 * Mantém um conjunto de dados sincronizado com o banco na nuvem (tabela library_data).
 * Os dados ficam iguais em qualquer computador que abrir o aplicativo.
 */
export function useCloudCollection<T>(
  key: string,
  initial: T,
): [T, (value: Setter<T>) => void, boolean] {
  const [value, setValueState] = useState<T>(() => {
    try {
      const cached = localStorage.getItem(`bmq_cloud_${key}`);
      if (cached) return JSON.parse(cached);
    } catch {
      // fallback to initial
    }
    return initial;
  });
  const [loaded, setLoaded] = useState(false);
  const loadedRef = useRef(false);
  const lastSyncedRef = useRef<string>("");
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const initialRef = useRef(initial);

  // Carrega da nuvem (semeando com os dados iniciais na primeira vez)
  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      const { data, error } = await supabase
        .from("library_data")
        .select("value")
        .eq("key", key)
        .maybeSingle();

      if (cancelled) return;

      if (error) {
        console.error(`Falha ao carregar "${key}" da nuvem:`, error.message);
        setLoaded(true);
        loadedRef.current = true;
        return;
      }

      if (data && data.value !== null && data.value !== undefined) {
        const remote = data.value as T;
        lastSyncedRef.current = JSON.stringify(remote);
        setValueState(remote);
        try {
          localStorage.setItem(`bmq_cloud_${key}`, JSON.stringify(remote));
        } catch {
          // ignore
        }
      } else {
        const seed = initialRef.current;
        lastSyncedRef.current = JSON.stringify(seed);
        await supabase
          .from("library_data")
          .upsert({ key, value: seed as never, updated_at: new Date().toISOString() });
      }

      setLoaded(true);
      loadedRef.current = true;
    };

    void load();

    const channel = supabase
      .channel(`library_data_${key}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "library_data", filter: `key=eq.${key}` },
        (payload) => {
          const next = (payload.new as { value?: unknown } | null)?.value;
          if (next === undefined || next === null) return;
          const serialized = JSON.stringify(next);
          if (serialized === lastSyncedRef.current) return;
          lastSyncedRef.current = serialized;
          setValueState(next as T);
          try {
            localStorage.setItem(`bmq_cloud_${key}`, serialized);
          } catch {
            // ignore
          }
        },
      )
      .subscribe();

    return () => {
      cancelled = true;
      void supabase.removeChannel(channel);
    };
  }, [key]);

  const setValue = useCallback(
    (next: Setter<T>) => {
      setValueState((prev) => {
        const resolved = typeof next === "function" ? (next as (p: T) => T)(prev) : next;
        const serialized = JSON.stringify(resolved);

        try {
          localStorage.setItem(`bmq_cloud_${key}`, serialized);
        } catch {
          // ignore
        }

        if (loadedRef.current) {
          if (serialized !== lastSyncedRef.current) {
            lastSyncedRef.current = serialized;
            if (saveTimer.current) clearTimeout(saveTimer.current);
            saveTimer.current = setTimeout(() => {
              void supabase
                .from("library_data")
                .upsert({
                  key,
                  value: resolved as never,
                  updated_at: new Date().toISOString(),
                })
                .then(({ error }) => {
                  if (error) console.error(`Falha ao salvar "${key}":`, error.message);
                });
            }, 400);
          }
        }

        return resolved;
      });
    },
    [key],
  );

  return [value, setValue, loaded];
}
