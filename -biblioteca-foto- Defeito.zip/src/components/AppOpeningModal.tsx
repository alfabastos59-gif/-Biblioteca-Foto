import React, { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import aberturaAsset from "../assets/abertura.mp4.asset.json";

interface AppOpeningModalProps {
  isOpen: boolean;
  onClose: () => void;
  autoPlay?: boolean;
}

export const AppOpeningModal: React.FC<AppOpeningModalProps> = ({
  isOpen,
  onClose,
  autoPlay = true,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hasClosedRef = useRef(false);
  const [isMuted, setIsMuted] = useState(true);

  const videoSrc = aberturaAsset.url;

  useEffect(() => {
    if (!isOpen) return;

    hasClosedRef.current = false;

    // Tenta reproduzir o vídeo automaticamente
    const playTimer = setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {
          // Autoplay bloqueado: silencia e tenta novamente
          setIsMuted(true);
          if (videoRef.current) {
            videoRef.current.muted = true;
            videoRef.current.play().catch(() => {});
          }
        });
      }
    }, 150);

    // Após 5 segundos, entra automaticamente na página principal
    const closeTimer = setTimeout(() => {
      if (!hasClosedRef.current) {
        hasClosedRef.current = true;
        onClose();
      }
    }, 5000);

    return () => {
      clearTimeout(playTimer);
      clearTimeout(closeTimer);
      if (videoRef.current) {
        videoRef.current.pause();
      }
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        id="app-opening-overlay"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black select-none"
      >
        <video
          ref={videoRef}
          src={videoSrc}
          playsInline
          autoPlay={autoPlay}
          muted={isMuted}
          className="w-full h-full object-cover"
        />
      </motion.div>
    </AnimatePresence>
  );
};
