import React, { useState, useEffect } from "react";
import { X, Star, Heart, BookmarkCheck, MapPin, BookOpen, Check, Layers } from "lucide-react";
import { Book } from "../types";
import { useTheme } from "../context/ThemeContext";
import { getCategoryColor } from "../data/mockData";

interface BookDetailModalProps {
  book: Book | null;
  onClose: () => void;
  onRequestLoan: (book: Book) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (bookId: string) => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  onClose,
  onRequestLoan,
  isFavorite = false,
  onToggleFavorite,
}) => {
  const { isDark } = useTheme();
  const [copied, setCopied] = useState(false);

  // Fecha a janela ao pressionar tecla ESC
  useEffect(() => {
    if (!book) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [book, onClose]);

  if (!book) return null;

  const handleCopyLocation = () => {
    navigator.clipboard?.writeText(book.location);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto bg-black/75 backdrop-blur-sm animate-in fade-in duration-200 cursor-pointer"
    >
      {/* Modal Container - stopPropagation garante que clicar dentro não fecha */}
      <div
        onClick={(e) => e.stopPropagation()}
        className={`relative z-10 w-full max-w-lg md:max-w-xl max-h-[88vh] flex flex-col border rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-2xl overflow-y-auto animate-in zoom-in-95 duration-200 cursor-default ${
          isDark
            ? "bg-[#092032] border-[#163650] text-white"
            : "bg-white border-slate-200 text-slate-900"
        }`}
      >
        {/* Close Button */}
        <button
          id="btn-close-book-modal"
          onClick={onClose}
          className={`absolute top-3.5 right-3.5 sm:top-4 sm:right-4 p-1.5 rounded-full border transition-colors cursor-pointer z-10 ${
            isDark
              ? "bg-[#031320] text-slate-400 hover:text-white border-[#163650]"
              : "bg-slate-100 text-slate-500 hover:text-slate-900 border-slate-200"
          }`}
          title="Fechar"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 sm:gap-5 items-start">
          {/* Left Column: Book Cover */}
          <div className="sm:col-span-4 flex flex-col items-center">
            <div
              className={`relative aspect-[3/4] w-full max-w-[140px] sm:max-w-[160px] rounded-xl overflow-hidden border-2 shadow-lg ${
                isDark ? "bg-[#031320] border-[#1e3a5f]/60" : "bg-slate-100 border-slate-200"
              }`}
            >
              <img src={book.cover} alt={book.title} className="w-full h-full object-cover" />
              <div className="absolute top-2 left-2">
                <span className="bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md backdrop-blur-sm">
                  {book.status === "disponivel"
                    ? "Disponível"
                    : book.status === "reservado"
                      ? "Reservado"
                      : "Em andamento"}
                </span>
              </div>
            </div>

            {/* Copies info */}
            <div
              className={`mt-2 flex items-center gap-1.5 text-[11px] ${isDark ? "text-slate-400" : "text-slate-500"}`}
            >
              <Layers className="w-3 h-3 text-emerald-500" />
              <span>
                {book.availableCopies} de {book.totalCopies} disponíveis
              </span>
            </div>
          </div>

          {/* Right Column: Metadata and Actions */}
          <div className="sm:col-span-8 flex flex-col justify-between min-w-0">
            <div>
              {/* Title & Author */}
              <h2
                className={`text-lg sm:text-xl font-black tracking-tight leading-snug mb-0.5 pr-8 ${isDark ? "text-white" : "text-slate-900"}`}
              >
                {book.title}
              </h2>
              <p
                className={`text-xs sm:text-sm font-medium mb-2 ${isDark ? "text-slate-300" : "text-slate-600"}`}
              >
                {book.author}
              </p>

              {/* Star Rating */}
              <div className="flex items-center gap-1.5 mb-3 text-xs">
                <div className="flex items-center text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < Math.floor(book.rating)
                          ? "fill-amber-400 text-amber-400"
                          : isDark
                            ? "text-slate-700"
                            : "text-slate-300"
                      }`}
                    />
                  ))}
                </div>
                <span className={`font-bold ${isDark ? "text-white" : "text-slate-900"}`}>
                  {book.rating}
                </span>
                <span className={`text-[11px] ${isDark ? "text-slate-400" : "text-slate-500"}`}>
                  ({book.reviewsCount} avaliações)
                </span>
              </div>

              {/* Metadata List */}
              <div
                className={`space-y-1.5 p-3 rounded-xl border mb-3 text-xs ${
                  isDark ? "bg-[#031320]/60 border-[#163650]/80" : "bg-slate-50 border-slate-200"
                }`}
              >
                <div
                  className={`flex justify-between items-center pb-1 border-b ${isDark ? "border-[#163650]/40" : "border-slate-200"}`}
                >
                  <span className={isDark ? "text-slate-400" : "text-slate-500"}>Categoria:</span>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[11px] font-bold text-white shadow-xs ${getCategoryColor(book.category).bg}`}
                  >
                    {book.category}
                  </span>
                </div>
                <div
                  className={`flex justify-between items-center pb-1 border-b ${isDark ? "border-[#163650]/40" : "border-slate-200"}`}
                >
                  <span className={isDark ? "text-slate-400" : "text-slate-500"}>Páginas:</span>
                  <span className={`font-semibold ${isDark ? "text-white" : "text-slate-900"}`}>
                    {book.pages}
                  </span>
                </div>
                <div
                  className={`flex justify-between items-center pb-1 border-b ${isDark ? "border-[#163650]/40" : "border-slate-200"}`}
                >
                  <span className={isDark ? "text-slate-400" : "text-slate-500"}>Ano:</span>
                  <span className={`font-semibold ${isDark ? "text-white" : "text-slate-900"}`}>
                    {book.year}
                  </span>
                </div>
                <div
                  className={`flex justify-between items-center pb-1 border-b ${isDark ? "border-[#163650]/40" : "border-slate-200"}`}
                >
                  <span className={isDark ? "text-slate-400" : "text-slate-500"}>Editora:</span>
                  <span className={`font-semibold ${isDark ? "text-white" : "text-slate-900"}`}>
                    {book.publisher}
                  </span>
                </div>
                <div className="flex justify-between items-center pt-0.5">
                  <span
                    className={`flex items-center gap-1 ${isDark ? "text-slate-400" : "text-slate-500"}`}
                  >
                    <MapPin className="w-3 h-3 text-emerald-500" />
                    Localização:
                  </span>
                  <button
                    onClick={handleCopyLocation}
                    title="Clique para copiar"
                    className="text-emerald-500 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>{book.location}</span>
                    {copied && <Check className="w-3 h-3 text-emerald-500" />}
                  </button>
                </div>
              </div>

              {/* Action Buttons - Grid lado a lado */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
                <button
                  id="btn-solicitar-emprestimo-modal"
                  onClick={() => onRequestLoan(book)}
                  disabled={book.availableCopies === 0}
                  className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer ${
                    book.availableCopies > 0
                      ? "bg-emerald-600 hover:bg-emerald-500 text-white"
                      : isDark
                        ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                        : "bg-slate-200 text-slate-400 cursor-not-allowed"
                  }`}
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>{book.availableCopies > 0 ? "Solicitar Empréstimo" : "Indisponível"}</span>
                </button>

                <button
                  id="btn-favoritos-modal"
                  onClick={() => onToggleFavorite?.(book.id)}
                  className={`py-2.5 px-3 rounded-xl font-semibold text-xs sm:text-sm border flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isFavorite
                      ? "bg-rose-500/10 text-rose-500 border-rose-500/40"
                      : isDark
                        ? "bg-[#031320] text-slate-300 border-[#163650] hover:text-white"
                        : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
                  }`}
                >
                  <Heart
                    className={`w-3.5 h-3.5 ${isFavorite ? "fill-rose-500 text-rose-500" : ""}`}
                  />
                  <span>{isFavorite ? "Favoritado" : "Favoritos"}</span>
                </button>
              </div>

              {/* Sobre o livro */}
              <div>
                <h4
                  className={`text-xs font-bold mb-1 flex items-center gap-1.5 ${isDark ? "text-white" : "text-slate-900"}`}
                >
                  <BookOpen className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Sobre o livro</span>
                </h4>
                <p
                  className={`text-[11px] sm:text-xs leading-relaxed max-h-24 overflow-y-auto pr-1 ${isDark ? "text-slate-300" : "text-slate-600"}`}
                >
                  {book.synopsis}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
